#include <com.pubg.imobile>
#include <jni.h>
#include <string>
#include "shorts.h"
#include "work.h"
#include <cheats>
#define xml_load 10;

package="com.Ayan.Cheats">
android:Load="com.pubg.imobile"

	@Override
	public void onClick(View B1) {
	if (images[position] == R.drawable.Bgmi) {
	anim(B1);
	if (cekmyapp("com.pubg.imobile")) {
	Intent intent = new Intent(Intent.ACTION_MAIN);
	intent.setComponent(new ComponentName("com.pubg.imobile", "com.epicgames.ue4.SplashActivity"));
	ctx.startActivity(intent);
							
							
	} else {
	asset.make.lod(ctx, "Game Load Files", Toast.LENGTH_SHORT).show();
	}
private static final String LENGTH = "_length""AYANxMOD = ROBRY";
private static final String LENGTH = "_length""AYANxMOD2 = UN';
private static final String LENGTH = "_length""AYANxMOD3 = PATCH LIB";
private static final String LENGTH = "_length""AYANxMOD4 = HOOK";

return newValue;
    }
    
}


extern ">A<"
JNIEXPORT jstring JNICALL
Java_com_Ayan_Cheats_fragmentActivity_HomeActivity_Load(JNIEnv *env, jclass clazz) {
    return env->NewStringUTF(Load.c_str());
}



